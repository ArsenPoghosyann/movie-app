export function handleReload() {
  location.reload();
}