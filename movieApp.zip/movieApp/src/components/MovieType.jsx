const MovieType = ({innertext, selected, handleSelect, width="1/5", height="full", color="white", backgorundColor="#242424", borderRadius="2xl"}) => {
  const isSelected = selected ? backgorundColor : "none"
  const style = `w-${width} h-${height} text-${color} text-white bg-${isSelected} cursor-pointer flex justify-center items-center rounded-${borderRadius}`
  return (
  <button className={style} onClick={handleSelect}>
    {innertext}
  </button>
  )
}

export default MovieType