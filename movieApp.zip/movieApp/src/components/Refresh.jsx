import { handleReload } from "../js/handleReload"

const Refresh = ({innertext="Movie App", width="auto", height="auto", backgorundColor="white", color="black", fontSize="base", borderRadius="none"}) => {
  const styles = `w-[${width}] h-[${height}] bg-[${backgorundColor}] text-[${color}] text-[${fontSize}] rounded-[${borderRadius}] cursor-pointer`;
  return (
    <button className={styles} onClick={handleReload}>
      {innertext}
    </button>
  )
}

export default Refresh