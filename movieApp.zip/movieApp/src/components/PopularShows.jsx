import MovieTypes from "./MovieTypes"

const PopularShows = () => {
  return (
    <section className="flex justify-center items-center flex-col pt-50">
      <span className="text-6xl">Popular shows</span>
      <MovieTypes width="1/2" height="15" t1="Movies" t2="TV Shows" t3="Animation" t4="Anime"/>
    </section>
  )
}

export default PopularShows