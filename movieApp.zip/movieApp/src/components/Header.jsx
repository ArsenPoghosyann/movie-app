import Refresh from "./Refresh"
import MovieTypes from "./MovieTypes"
import Search from "./Search"

const Header = () => {
  return (
    <header className="w-full h-25 flex justify-around items-center">
      <Refresh width="10%" height="50%" backgorundColor="transparent" color="gold-yellow" fontSize="20px" borderRadius="20px"/>
      <MovieTypes width="1/3" height="1/2" t1="Home" t2="Movies" t3="Series" t4="Kids"/>
      <Search />
    </header>
  )
}

export default Header