import MovieType from "./MovieType";
import { useState } from "react";

const MovieTypes = ({width, height, t1, t2, t3, t4}) => {
  const [movieTypes, setMovieTypes] = useState([
    {name: t1, selected: true},
    {name: t2, selected: false},
    {name: t3, selected: false},
    {name: t4, selected: false}
  ]);
  function handleSelect(index) {
    setMovieTypes(prev =>
      prev.map((item, i) => ({
        ...item,
        selected: i === index,
      }))
    );
  }
  return (
    <div className={`w-${width} h-${height} bg-black rounded-3xl flex items-center justify-between p-2`}>
      {movieTypes.map((el, index) => <MovieType key={el.name} innertext={el.name} selected={el.selected} handleSelect={() => handleSelect(index)} />)}
    </div>
  )
}

export default MovieTypes
