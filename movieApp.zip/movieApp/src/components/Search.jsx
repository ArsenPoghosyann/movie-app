const Search = ({}) => {
  return (
    <button>
      <span className="material-symbols-outlined">
        search
      </span>
    </button>
  )
}

export default Search