import Header from "./components/Header"
import PopularShows from "./components/PopularShows"

function App() {
  return (
    <div className="w-screen h-screen h-">
      <Header />
      <PopularShows />
    </div>
  )
}

export default App
